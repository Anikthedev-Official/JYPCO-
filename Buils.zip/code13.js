gdjs.LEVEL12Code = {};
gdjs.LEVEL12Code.localVariables = [];
gdjs.LEVEL12Code.idToCallbackMap = new Map();
gdjs.LEVEL12Code.GDPlayerObjects1= [];
gdjs.LEVEL12Code.GDPlayerObjects2= [];
gdjs.LEVEL12Code.GDBackgroundObjects1= [];
gdjs.LEVEL12Code.GDBackgroundObjects2= [];
gdjs.LEVEL12Code.GDCoinsObjects1= [];
gdjs.LEVEL12Code.GDCoinsObjects2= [];
gdjs.LEVEL12Code.GDJumpButtonObjects1= [];
gdjs.LEVEL12Code.GDJumpButtonObjects2= [];
gdjs.LEVEL12Code.GDMoveJoystickObjects1= [];
gdjs.LEVEL12Code.GDMoveJoystickObjects2= [];
gdjs.LEVEL12Code.GDPlatform_9595GroundObjects1= [];
gdjs.LEVEL12Code.GDPlatform_9595GroundObjects2= [];
gdjs.LEVEL12Code.GDPlatform_9595Ground2Objects1= [];
gdjs.LEVEL12Code.GDPlatform_9595Ground2Objects2= [];
gdjs.LEVEL12Code.GDNewSpriteObjects1= [];
gdjs.LEVEL12Code.GDNewSpriteObjects2= [];
gdjs.LEVEL12Code.GDLadderGroundObjects1= [];
gdjs.LEVEL12Code.GDLadderGroundObjects2= [];
gdjs.LEVEL12Code.GDNewSprite2Objects1= [];
gdjs.LEVEL12Code.GDNewSprite2Objects2= [];
gdjs.LEVEL12Code.GDSmallGreenButtonObjects1= [];
gdjs.LEVEL12Code.GDSmallGreenButtonObjects2= [];
gdjs.LEVEL12Code.GDNewTextObjects1= [];
gdjs.LEVEL12Code.GDNewTextObjects2= [];
gdjs.LEVEL12Code.GDNewTiledSpriteObjects1= [];
gdjs.LEVEL12Code.GDNewTiledSpriteObjects2= [];
gdjs.LEVEL12Code.GDNewSprite3Objects1= [];
gdjs.LEVEL12Code.GDNewSprite3Objects2= [];
gdjs.LEVEL12Code.GDJumpButton2Objects1= [];
gdjs.LEVEL12Code.GDJumpButton2Objects2= [];
gdjs.LEVEL12Code.GDNewText2Objects1= [];
gdjs.LEVEL12Code.GDNewText2Objects2= [];
gdjs.LEVEL12Code.GDHealthBarBoxObjects1= [];
gdjs.LEVEL12Code.GDHealthBarBoxObjects2= [];
gdjs.LEVEL12Code.GDHealthBarObjects1= [];
gdjs.LEVEL12Code.GDHealthBarObjects2= [];
gdjs.LEVEL12Code.GDPortal_9595BottomObjects1= [];
gdjs.LEVEL12Code.GDPortal_9595BottomObjects2= [];
gdjs.LEVEL12Code.GDPortal_9595MiddleObjects1= [];
gdjs.LEVEL12Code.GDPortal_9595MiddleObjects2= [];
gdjs.LEVEL12Code.GDPortal_9595TopObjects1= [];
gdjs.LEVEL12Code.GDPortal_9595TopObjects2= [];


gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL12Code.GDPlayerObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDCoinsObjects1Objects = Hashtable.newFrom({"Coins": gdjs.LEVEL12Code.GDCoinsObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL12Code.GDPlayerObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlatform_95959595Ground2Objects1Objects = Hashtable.newFrom({"Platform_Ground2": gdjs.LEVEL12Code.GDPlatform_9595Ground2Objects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL12Code.GDPlayerObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPortal_95959595TopObjects1Objects = Hashtable.newFrom({"Portal_Top": gdjs.LEVEL12Code.GDPortal_9595TopObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL12Code.GDPlayerObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.LEVEL12Code.GDNewSprite3Objects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL12Code.GDPlayerObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.LEVEL12Code.GDNewSprite3Objects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDJumpButton2Objects1Objects = Hashtable.newFrom({"JumpButton2": gdjs.LEVEL12Code.GDJumpButton2Objects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL12Code.GDPlayerObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.LEVEL12Code.GDNewSprite3Objects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDJumpButton2Objects1Objects = Hashtable.newFrom({"JumpButton2": gdjs.LEVEL12Code.GDJumpButton2Objects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL12Code.GDPlayerObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPortal_95959595MiddleObjects1Objects = Hashtable.newFrom({"Portal_Middle": gdjs.LEVEL12Code.GDPortal_9595MiddleObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.LEVEL12Code.GDPlayerObjects1});
gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPortal_95959595BottomObjects1Objects = Hashtable.newFrom({"Portal_Bottom": gdjs.LEVEL12Code.GDPortal_9595BottomObjects1});
gdjs.LEVEL12Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Background", 0);
}
{gdjs.evtTools.runtimeScene.prioritizeLoadingOfScene(runtimeScene, "LEVEL3");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Coins"), gdjs.LEVEL12Code.GDCoinsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects, gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDCoinsObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL12Code.GDCoinsObjects1 */
{for(var i = 0, len = gdjs.LEVEL12Code.GDCoinsObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDCoinsObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "PickupCoin", false, 80, gdjs.randomFloatInRange(1, 1.1));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Platform_Ground2"), gdjs.LEVEL12Code.GDPlatform_9595Ground2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.platform.isOnPlatform(gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects, "PlatformerObject", gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlatform_95959595Ground2Objects1Objects, false);
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL12Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].activateBehavior("PlatformerObject", false);
}
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "lost", false);
}
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].activateBehavior("PlatformerMultitouchMapper", false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal_Top"), gdjs.LEVEL12Code.GDPortal_9595TopObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects, gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPortal_95959595TopObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mENU", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("crouch");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "LControl");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("idle");
}
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.LEVEL12Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects, gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDNewSprite3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL12Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isUsingControl("Up") ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL12Code.GDPlayerObjects1[k] = gdjs.LEVEL12Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.LEVEL12Code.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL12Code.GDNewSprite3Objects1 */
{for(var i = 0, len = gdjs.LEVEL12Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDNewSprite3Objects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "BeepBox-Song.mp3", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.LEVEL12Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects, gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDNewSprite3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL12Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL12Code.GDPlayerObjects1[k] = gdjs.LEVEL12Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.LEVEL12Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8414588);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.LEVEL12Code.GDHealthBarObjects1);
/* Reuse gdjs.LEVEL12Code.GDNewSprite3Objects1 */
/* Reuse gdjs.LEVEL12Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.LEVEL12Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDNewSprite3Objects1[i].getBehavior("Animation").setAnimationName("Bitwe");
}
}
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Biten");
}
}
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].returnVariable(gdjs.LEVEL12Code.GDPlayerObjects1[i].getVariables().getFromIndex(0)).sub(25);
}
}
{for(var i = 0, len = gdjs.LEVEL12Code.GDHealthBarObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDHealthBarObjects1[i].getBehavior("Resizable").setWidth(gdjs.evtTools.common.clamp((gdjs.RuntimeObject.getVariableNumber(((gdjs.LEVEL12Code.GDPlayerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LEVEL12Code.GDPlayerObjects1[0].getVariables()).getFromIndex(0))) / (gdjs.RuntimeObject.getVariableNumber(((gdjs.LEVEL12Code.GDPlayerObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.LEVEL12Code.GDPlayerObjects1[0].getVariables()).getFromIndex(1))) * 153, 0, 100));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.LEVEL12Code.GDNewSprite3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL12Code.GDNewSprite3Objects1.length;i<l;++i) {
    if ( gdjs.LEVEL12Code.GDNewSprite3Objects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL12Code.GDNewSprite3Objects1[k] = gdjs.LEVEL12Code.GDNewSprite3Objects1[i];
        ++k;
    }
}
gdjs.LEVEL12Code.GDNewSprite3Objects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL12Code.GDNewSprite3Objects1 */
{for(var i = 0, len = gdjs.LEVEL12Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDNewSprite3Objects1[i].getBehavior("Animation").setAnimationName("idle");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.LEVEL12Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.LEVEL12Code.GDPlayerObjects1[k] = gdjs.LEVEL12Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.LEVEL12Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL12Code.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].setPosition(355,315);
}
}
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("idle");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.LEVEL12Code.GDMoveJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.LEVEL12Code.GDMoveJoystickObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDMoveJoystickObjects1[i].ActivateControl(false, null);
}
}
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("HIT THEM");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton2"), gdjs.LEVEL12Code.GDJumpButton2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDJumpButton2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);
{for(var i = 0, len = gdjs.LEVEL12Code.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("HIT THEM");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.LEVEL12Code.GDJumpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("JumpButton2"), gdjs.LEVEL12Code.GDJumpButton2Objects1);
gdjs.copyArray(runtimeScene.getObjects("MoveJoystick"), gdjs.LEVEL12Code.GDMoveJoystickObjects1);
{for(var i = 0, len = gdjs.LEVEL12Code.GDJumpButtonObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDJumpButtonObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.LEVEL12Code.GDJumpButton2Objects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDJumpButton2Objects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.LEVEL12Code.GDMoveJoystickObjects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDMoveJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton2"), gdjs.LEVEL12Code.GDJumpButton2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.LEVEL12Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects, gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDNewSprite3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDJumpButton2Objects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.LEVEL12Code.GDNewSprite3Objects1 */
{for(var i = 0, len = gdjs.LEVEL12Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.LEVEL12Code.GDNewSprite3Objects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "BeepBox-Song.mp3", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal_Middle"), gdjs.LEVEL12Code.GDPortal_9595MiddleObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects, gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPortal_95959595MiddleObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mENU", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.LEVEL12Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal_Bottom"), gdjs.LEVEL12Code.GDPortal_9595BottomObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPlayerObjects1Objects, gdjs.LEVEL12Code.mapOfGDgdjs_9546LEVEL12Code_9546GDPortal_95959595BottomObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "mENU", false);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.LEVEL12Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LEVEL12Code.GDPlayerObjects1.length = 0;
gdjs.LEVEL12Code.GDPlayerObjects2.length = 0;
gdjs.LEVEL12Code.GDBackgroundObjects1.length = 0;
gdjs.LEVEL12Code.GDBackgroundObjects2.length = 0;
gdjs.LEVEL12Code.GDCoinsObjects1.length = 0;
gdjs.LEVEL12Code.GDCoinsObjects2.length = 0;
gdjs.LEVEL12Code.GDJumpButtonObjects1.length = 0;
gdjs.LEVEL12Code.GDJumpButtonObjects2.length = 0;
gdjs.LEVEL12Code.GDMoveJoystickObjects1.length = 0;
gdjs.LEVEL12Code.GDMoveJoystickObjects2.length = 0;
gdjs.LEVEL12Code.GDPlatform_9595GroundObjects1.length = 0;
gdjs.LEVEL12Code.GDPlatform_9595GroundObjects2.length = 0;
gdjs.LEVEL12Code.GDPlatform_9595Ground2Objects1.length = 0;
gdjs.LEVEL12Code.GDPlatform_9595Ground2Objects2.length = 0;
gdjs.LEVEL12Code.GDNewSpriteObjects1.length = 0;
gdjs.LEVEL12Code.GDNewSpriteObjects2.length = 0;
gdjs.LEVEL12Code.GDLadderGroundObjects1.length = 0;
gdjs.LEVEL12Code.GDLadderGroundObjects2.length = 0;
gdjs.LEVEL12Code.GDNewSprite2Objects1.length = 0;
gdjs.LEVEL12Code.GDNewSprite2Objects2.length = 0;
gdjs.LEVEL12Code.GDSmallGreenButtonObjects1.length = 0;
gdjs.LEVEL12Code.GDSmallGreenButtonObjects2.length = 0;
gdjs.LEVEL12Code.GDNewTextObjects1.length = 0;
gdjs.LEVEL12Code.GDNewTextObjects2.length = 0;
gdjs.LEVEL12Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.LEVEL12Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.LEVEL12Code.GDNewSprite3Objects1.length = 0;
gdjs.LEVEL12Code.GDNewSprite3Objects2.length = 0;
gdjs.LEVEL12Code.GDJumpButton2Objects1.length = 0;
gdjs.LEVEL12Code.GDJumpButton2Objects2.length = 0;
gdjs.LEVEL12Code.GDNewText2Objects1.length = 0;
gdjs.LEVEL12Code.GDNewText2Objects2.length = 0;
gdjs.LEVEL12Code.GDHealthBarBoxObjects1.length = 0;
gdjs.LEVEL12Code.GDHealthBarBoxObjects2.length = 0;
gdjs.LEVEL12Code.GDHealthBarObjects1.length = 0;
gdjs.LEVEL12Code.GDHealthBarObjects2.length = 0;
gdjs.LEVEL12Code.GDPortal_9595BottomObjects1.length = 0;
gdjs.LEVEL12Code.GDPortal_9595BottomObjects2.length = 0;
gdjs.LEVEL12Code.GDPortal_9595MiddleObjects1.length = 0;
gdjs.LEVEL12Code.GDPortal_9595MiddleObjects2.length = 0;
gdjs.LEVEL12Code.GDPortal_9595TopObjects1.length = 0;
gdjs.LEVEL12Code.GDPortal_9595TopObjects2.length = 0;

gdjs.LEVEL12Code.eventsList0(runtimeScene);
gdjs.LEVEL12Code.GDPlayerObjects1.length = 0;
gdjs.LEVEL12Code.GDPlayerObjects2.length = 0;
gdjs.LEVEL12Code.GDBackgroundObjects1.length = 0;
gdjs.LEVEL12Code.GDBackgroundObjects2.length = 0;
gdjs.LEVEL12Code.GDCoinsObjects1.length = 0;
gdjs.LEVEL12Code.GDCoinsObjects2.length = 0;
gdjs.LEVEL12Code.GDJumpButtonObjects1.length = 0;
gdjs.LEVEL12Code.GDJumpButtonObjects2.length = 0;
gdjs.LEVEL12Code.GDMoveJoystickObjects1.length = 0;
gdjs.LEVEL12Code.GDMoveJoystickObjects2.length = 0;
gdjs.LEVEL12Code.GDPlatform_9595GroundObjects1.length = 0;
gdjs.LEVEL12Code.GDPlatform_9595GroundObjects2.length = 0;
gdjs.LEVEL12Code.GDPlatform_9595Ground2Objects1.length = 0;
gdjs.LEVEL12Code.GDPlatform_9595Ground2Objects2.length = 0;
gdjs.LEVEL12Code.GDNewSpriteObjects1.length = 0;
gdjs.LEVEL12Code.GDNewSpriteObjects2.length = 0;
gdjs.LEVEL12Code.GDLadderGroundObjects1.length = 0;
gdjs.LEVEL12Code.GDLadderGroundObjects2.length = 0;
gdjs.LEVEL12Code.GDNewSprite2Objects1.length = 0;
gdjs.LEVEL12Code.GDNewSprite2Objects2.length = 0;
gdjs.LEVEL12Code.GDSmallGreenButtonObjects1.length = 0;
gdjs.LEVEL12Code.GDSmallGreenButtonObjects2.length = 0;
gdjs.LEVEL12Code.GDNewTextObjects1.length = 0;
gdjs.LEVEL12Code.GDNewTextObjects2.length = 0;
gdjs.LEVEL12Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.LEVEL12Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.LEVEL12Code.GDNewSprite3Objects1.length = 0;
gdjs.LEVEL12Code.GDNewSprite3Objects2.length = 0;
gdjs.LEVEL12Code.GDJumpButton2Objects1.length = 0;
gdjs.LEVEL12Code.GDJumpButton2Objects2.length = 0;
gdjs.LEVEL12Code.GDNewText2Objects1.length = 0;
gdjs.LEVEL12Code.GDNewText2Objects2.length = 0;
gdjs.LEVEL12Code.GDHealthBarBoxObjects1.length = 0;
gdjs.LEVEL12Code.GDHealthBarBoxObjects2.length = 0;
gdjs.LEVEL12Code.GDHealthBarObjects1.length = 0;
gdjs.LEVEL12Code.GDHealthBarObjects2.length = 0;
gdjs.LEVEL12Code.GDPortal_9595BottomObjects1.length = 0;
gdjs.LEVEL12Code.GDPortal_9595BottomObjects2.length = 0;
gdjs.LEVEL12Code.GDPortal_9595MiddleObjects1.length = 0;
gdjs.LEVEL12Code.GDPortal_9595MiddleObjects2.length = 0;
gdjs.LEVEL12Code.GDPortal_9595TopObjects1.length = 0;
gdjs.LEVEL12Code.GDPortal_9595TopObjects2.length = 0;


return;

}

gdjs['LEVEL12Code'] = gdjs.LEVEL12Code;
