gdjs.TEST_32NAVIGATIONCode = {};
gdjs.TEST_32NAVIGATIONCode.localVariables = [];
gdjs.TEST_32NAVIGATIONCode.idToCallbackMap = new Map();
gdjs.TEST_32NAVIGATIONCode.GDGDevelop_9595red_9595heroObjects1= [];
gdjs.TEST_32NAVIGATIONCode.GDGDevelop_9595red_9595heroObjects2= [];
gdjs.TEST_32NAVIGATIONCode.GDRed_9595heroObjects1= [];
gdjs.TEST_32NAVIGATIONCode.GDRed_9595heroObjects2= [];
gdjs.TEST_32NAVIGATIONCode.GDNewSpriteObjects1= [];
gdjs.TEST_32NAVIGATIONCode.GDNewSpriteObjects2= [];
gdjs.TEST_32NAVIGATIONCode.GDNewTextObjects1= [];
gdjs.TEST_32NAVIGATIONCode.GDNewTextObjects2= [];
gdjs.TEST_32NAVIGATIONCode.GDNewSprite2Objects1= [];
gdjs.TEST_32NAVIGATIONCode.GDNewSprite2Objects2= [];
gdjs.TEST_32NAVIGATIONCode.GDHealthBarBoxObjects1= [];
gdjs.TEST_32NAVIGATIONCode.GDHealthBarBoxObjects2= [];
gdjs.TEST_32NAVIGATIONCode.GDHealthBarObjects1= [];
gdjs.TEST_32NAVIGATIONCode.GDHealthBarObjects2= [];
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595BottomObjects1= [];
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595BottomObjects2= [];
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595MiddleObjects1= [];
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595MiddleObjects2= [];
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595TopObjects1= [];
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595TopObjects2= [];


gdjs.TEST_32NAVIGATIONCode.mapOfGDgdjs_9546TEST_959532NAVIGATIONCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite": gdjs.TEST_32NAVIGATIONCode.GDNewSpriteObjects1});
gdjs.TEST_32NAVIGATIONCode.mapOfGDgdjs_9546TEST_959532NAVIGATIONCode_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.TEST_32NAVIGATIONCode.GDNewSprite2Objects1});
gdjs.TEST_32NAVIGATIONCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.TEST_32NAVIGATIONCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TEST_32NAVIGATIONCode.mapOfGDgdjs_9546TEST_959532NAVIGATIONCode_9546GDNewSpriteObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TEST NAVIGATION", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.TEST_32NAVIGATIONCode.GDNewSprite2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TEST_32NAVIGATIONCode.mapOfGDgdjs_9546TEST_959532NAVIGATIONCode_9546GDNewSprite2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "LEVEL7", false);
}
}

}


};

gdjs.TEST_32NAVIGATIONCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TEST_32NAVIGATIONCode.GDGDevelop_9595red_9595heroObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDGDevelop_9595red_9595heroObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDRed_9595heroObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDRed_9595heroObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewSpriteObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewSpriteObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewTextObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewTextObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewSprite2Objects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewSprite2Objects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDHealthBarBoxObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDHealthBarBoxObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDHealthBarObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDHealthBarObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595BottomObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595BottomObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595MiddleObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595MiddleObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595TopObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595TopObjects2.length = 0;

gdjs.TEST_32NAVIGATIONCode.eventsList0(runtimeScene);
gdjs.TEST_32NAVIGATIONCode.GDGDevelop_9595red_9595heroObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDGDevelop_9595red_9595heroObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDRed_9595heroObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDRed_9595heroObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewSpriteObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewSpriteObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewTextObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewTextObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewSprite2Objects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDNewSprite2Objects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDHealthBarBoxObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDHealthBarBoxObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDHealthBarObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDHealthBarObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595BottomObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595BottomObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595MiddleObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595MiddleObjects2.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595TopObjects1.length = 0;
gdjs.TEST_32NAVIGATIONCode.GDPortal_9595TopObjects2.length = 0;


return;

}

gdjs['TEST_32NAVIGATIONCode'] = gdjs.TEST_32NAVIGATIONCode;
